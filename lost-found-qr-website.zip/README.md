# Lost & Found QR

A simple static Lost & Found QR prototype for a college DTPL project.

## Run on Replit
1. Create a new Replit project using HTML/CSS/JS.
2. Replace the default `index.html` with the provided `index.html`.
3. Click Run.

## Run on GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html`.
3. Go to Settings → Pages.
4. Select Deploy from branch → `main` → `/root`.
5. Save and open the generated Pages URL.

## Features
- Responsive landing page
- QR code generation
- Lost/found reporting
- Browser localStorage for submitted reports
- Search/filter items
- Demo records
- No backend required

Note: This is a front-end prototype. For a real system, use a backend/database and secure contact/notification system.
